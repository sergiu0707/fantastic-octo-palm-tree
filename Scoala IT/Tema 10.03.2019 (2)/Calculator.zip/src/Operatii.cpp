#include "Operatii.h"



int Adunare (int a, int b)
{
    return a + b;
}

int Scadere (int a, int b)
{
    return a - b;
}

int Inmultire (int a, int b)
{
    return a * b;
}

int Impartire (int a, int b)
{
    return a / b;
}

int Modulo (int a, int b)
{
    return a % b;
}
