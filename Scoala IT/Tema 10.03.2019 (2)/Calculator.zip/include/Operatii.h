#ifndef OPERATII_H
#define OPERATII_H


int Adunare (int a, int b);
int Scadere (int a, int b);
int Inmultire (int a, int b);
int Impartire(int a, int b);
int Modulo (int a, int b);
#endif // OPERATII_H
